INSERT INTO `Transaction_Type` (`id`, `type` ) VALUES ('0', 'CASH_IN');
INSERT INTO `Transaction_Type` (`id`, `type` ) VALUES ('1', 'CASH_OUT');
INSERT INTO `Transaction_Type` (`id`, `type` ) VALUES ('2', 'PAYMENT');
INSERT INTO `Transaction_Type` (`id`, `type` ) VALUES ('3', 'TRANSFER');
